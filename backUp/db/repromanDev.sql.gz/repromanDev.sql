-- Adminer 4.8.1 MySQL 5.7.10 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `orderId` int(11) NOT NULL AUTO_INCREMENT,
  `packetaId` int(11) DEFAULT NULL,
  `sessionId` varchar(200) COLLATE utf8_czech_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `agreement` int(11) NOT NULL,
  `product` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  `note` text COLLATE utf8_czech_ci,
  `name` varchar(200) COLLATE utf8_czech_ci DEFAULT NULL,
  `surname` varchar(200) COLLATE utf8_czech_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_czech_ci DEFAULT NULL,
  `email` varchar(250) COLLATE utf8_czech_ci DEFAULT NULL,
  `contactStreet` varchar(250) COLLATE utf8_czech_ci DEFAULT NULL,
  `contactCity` varchar(250) COLLATE utf8_czech_ci DEFAULT NULL,
  `contactPsc` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `billingStreet` varchar(250) COLLATE utf8_czech_ci DEFAULT NULL,
  `billingCity` varchar(250) COLLATE utf8_czech_ci DEFAULT NULL,
  `billingPsc` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastUpdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `packetaPlace` varchar(200) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

INSERT INTO `orders` (`orderId`, `packetaId`, `sessionId`, `status`, `agreement`, `product`, `note`, `name`, `surname`, `phone`, `email`, `contactStreet`, `contactCity`, `contactPsc`, `billingStreet`, `billingCity`, `billingPsc`, `created`, `lastUpdate`, `packetaPlace`) VALUES
(35,	NULL,	'h9ps7s0cua39qvtd7t235b20hd',	0,	1,	'two',	'',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'74141',	'',	'',	'',	'2021-12-06 14:34:23',	'2021-12-06 13:34:23',	''),
(36,	NULL,	'de1gkpi9ksmodf3rcerln90v0j',	0,	1,	'three',	'Nejaka poznamka.',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 14:36:39',	'2021-12-06 13:36:39',	''),
(37,	NULL,	'q14hibnqpvqqur5oiid3pcs703',	0,	1,	'one',	'fsdff',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 14:49:45',	'2021-12-06 13:49:45',	''),
(38,	NULL,	'hgahf46d0bs8u5r65ll21djufm',	2,	1,	'one',	'',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 14:52:02',	'2021-12-06 14:28:29',	''),
(39,	NULL,	'05i91eji7sc92tusk2dk2i7fg3',	0,	1,	'one',	'',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 14:54:18',	'2021-12-06 13:54:18',	''),
(40,	NULL,	'c6mg8gmp5qb8imibkutnh4q2h8',	0,	1,	'one',	'',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 14:57:16',	'2021-12-06 13:57:16',	''),
(41,	NULL,	'pih1o0iilbp9cmba6d141d2u4b',	1,	1,	'one',	'',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 14:58:20',	'2021-12-06 14:26:29',	''),
(42,	NULL,	'gkjndfceeo4s8ud9k100imsjqk',	1,	1,	'one',	'',	'Jiri',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Mesto',	'33333',	'',	'',	'',	'2021-12-06 15:02:49',	'2022-03-18 07:18:42',	''),
(49,	9381,	'37ttkruavm1p3oarael7b0tq4b',	1,	1,	'one',	'',	'jiri',	'wolf',	'608233334',	'wolf@jw.cz',	'ulice',	'mesto',	'76001',	'',	'',	'',	'2022-01-06 10:28:24',	'2022-02-03 05:56:42',	''),
(51,	9433,	'181700004b78851bbf2a39bb35206884',	1,	1,	'three',	'',	'Jiří',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Zlin',	'760 01',	'',	'',	'',	'2022-01-19 10:56:53',	'2022-03-18 07:18:09',	'Zlín, Jižní Svahy, Podlesí 2/5611 760 05'),
(52,	9433,	'5a7bb279807c18edcdfec26159080e89',	1,	1,	'one',	'',	'Jiří',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Zlín',	'760 01',	'',	'',	'',	'2022-01-19 11:15:22',	'2022-02-23 09:18:09',	'Zlín, Jižní Svahy, Podlesí 2/5611 760 05'),
(53,	1504,	'74bc28eb34247eb8c93fd35f589bdefa',	1,	1,	'two',	'',	'Jiří',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Zlín',	'760 01',	'',	'',	'',	'2022-01-20 08:16:30',	'2022-01-20 07:22:55',	'Zlín, Sadová 3053 (Kopírovací centrum) 760 01'),
(54,	1504,	'feddab7794d2347121204725e9cd884c',	2,	1,	'three',	'',	'Jiří',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Zlín',	'760 01',	'',	'',	'',	'2022-01-20 09:00:55',	'2022-01-20 08:06:38',	'Zlín, Sadová 3053 (Kopírovací centrum) 760 01'),
(55,	9433,	'104d8e586e6af0956011922713681dee',	2,	1,	'two',	'',	'Jiří',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Zlín',	'760 01',	'',	'',	'',	'2022-01-28 11:24:44',	'2022-02-03 05:57:29',	'Zlín, Jižní Svahy, Podlesí 2/5611 760 05'),
(56,	9433,	'fa6fb50b34f323386487c0a57ab7a7be',	1,	1,	'one',	'',	'Ales',	'Hoferek',	'44444',	'jiri.wolf@gmail.com',	'Hlavni',	'Zlín',	'760 01',	'',	'',	'',	'2022-02-22 12:32:14',	'2022-02-23 09:17:06',	'Zlín, Jižní Svahy, Podlesí 2/5611 760 05'),
(57,	22,	'dab27f72ca113b937f3e963bc0adda54',	1,	1,	'three',	'',	'Veronika',	'Vaďurová',	'601360527',	'Veronika.Vadurova@ivfzlin.cz',	'Kohoutkova 17',	'Zlín',	'76001',	'',	'',	'',	'2022-03-18 11:59:24',	'2022-03-21 13:20:38',	'Uherské Hradiště, Na Stavidle 453 686 01'),
(58,	2086,	'a585c32ca3824f21f9d602c985b007e9',	1,	1,	'two',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-03-18 12:09:11',	'2022-03-23 08:32:25',	'Zlín, Kostelec, Na Rusavě 181 763 14'),
(59,	8896,	'63a2000642aade5433e08b7b93ab96ad',	1,	1,	'two',	'',	'Veronika',	'Vaďurová',	'601360527',	'Veronika.Vadurova@ivfzlin.cz',	'Tomášov U Lomu 638',	'Zlín',	'76001',	'',	'',	'',	'2022-03-18 15:13:00',	'2022-03-21 13:19:55',	'Uherské Hradiště, Svatojiřské nábřeží 457 686 01'),
(60,	2086,	'253c5e30f1b7f949204833d4ba3919e6',	1,	1,	'one',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-03-21 09:37:09',	'2022-03-22 06:33:29',	'Zlín, Kostelec, Na Rusavě 181 763 14'),
(61,	5544,	'ce202715c3e085566b662d081fba3ec2',	1,	1,	'one',	'',	'Renata',	'Holíková',	'776609408',	'holikova.renata@seznam.cz',	'U Lomu',	'Zlín',	'76001',	'',	'',	'',	'2022-03-21 10:09:16',	'2022-03-23 08:33:37',	'Zlín, Nad Ovčírnou 1046 760 01'),
(62,	17570,	'a5db96c892d143fb380a5f14227103fb',	1,	1,	'one',	'',	'Leona',	'Marťanová',	'777 555 666',	'martan@seznam.cz',	'Zahradní 66',	'Zlín',	'76001',	'',	'',	'',	'2022-03-21 10:14:32',	'2022-03-21 11:23:45',	'Zlín, náměstí Míru 66 760 01'),
(63,	909,	'1fbcaf8f930f1945bc0dfa9aadba6192',	1,	1,	'three',	'',	'Ivana',	'Zamazalová',	'723792712',	'terapiezlin@seznam.cz',	'U Lomu 638',	'Zlín',	'76001',	'',	'',	'',	'2022-03-21 12:58:55',	'2022-03-21 13:42:10',	'Zlín, J. A. Bati 5542 760 01'),
(64,	2153,	'1125acb514bad5fce449a9451d4b93a2',	0,	1,	'three',	'',	'Karel',	'Opršálek',	'601360527',	'Veronika.Vadurova@ivfzlin.cz',	'Poštovní 47',	'Uherský Brod - Újezdec',	'68734',	'',	'',	'',	'2022-03-21 15:17:09',	'2022-03-22 06:26:10',	'Uherský Brod, nám. 1. máje 1571 688 01'),
(65,	2086,	'f28b5d88127baca5d34b6a99a5c5ee33',	1,	1,	'three',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-03-22 07:47:01',	'2022-03-22 06:57:48',	'Zlín, Kostelec, Na Rusavě 181 763 14'),
(66,	88,	'c6a69da750e16b5e3e2df1d1299d4822',	1,	1,	'two',	'',	'František',	'Koudelka',	'608258269',	'zuzka.vosmikova@seznam.cz',	'Květná 111',	'Praha',	'15000',	'',	'',	'',	'2022-03-23 09:06:24',	'2022-03-23 08:23:20',	'Praha 10, Starostrašnická 38, Dia-Bio-Racio-Bezlepek 100 00'),
(67,	2086,	'2142ad92ebd47e84688d2ae79d240ecd',	1,	1,	'one',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-03-24 08:05:13',	'2022-03-24 07:42:29',	'Zlín, Kostelec, Na Rusavě 181 763 14'),
(68,	9433,	'18b83c3bd40706f2e21d77e293f8c08f',	1,	1,	'two',	'',	'Jiří',	'Wolf',	'608233334',	'jiri.wolf@gmail.com',	'Ulice',	'Město',	'76001',	'',	'',	'',	'2022-03-24 14:01:34',	'2022-03-24 13:50:56',	'Zlín, Jižní Svahy, Podlesí 2/5611 760 05'),
(69,	9433,	'250ca0bba53d52978b04aad7b06261eb',	1,	1,	'one',	'',	'Jiří',	'Wolf',	'608233334',	'wolf@jw.cz',	'Ulice',	'Město',	'76001',	'',	'',	'',	'2022-03-24 14:20:05',	'2022-03-24 13:51:31',	'Zlín, Jižní Svahy, Podlesí 2/5611 760 05'),
(70,	2086,	'07784390c938ccf40f1f327156a7ca38',	1,	1,	'one',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-03-24 14:30:53',	'2022-03-24 13:51:55',	'Zlín, Kostelec, Na Rusavě 181 763 14'),
(71,	0,	'4d7eff01d8ccbe9f75f6c02de1294307',	0,	1,	'one',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-03-29 09:42:58',	'2022-03-29 07:42:58',	''),
(72,	2086,	'e4101c5ea41c0f515ced2ad0c766e83a',	1,	1,	'two',	'',	'Zuzana',	'Vosmíková',	'604146621',	'zuzka.vosmikova@seznam.cz',	'Květná 387',	'Zlín 12',	'76314',	'',	'',	'',	'2022-05-25 12:03:25',	'2022-05-25 11:33:56',	'Zlín, Kostelec, Na Rusavě 181 763 14');

DROP TABLE IF EXISTS `phinxlog`;
CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20220106102100,	'Ctvrtek',	'2022-01-06 10:21:00',	'2022-01-06 10:21:00',	0),
(20220106103301,	'TestMigrace',	'2022-01-06 10:35:40',	'2022-01-06 10:35:40',	0),
(20220106103632,	'Ctvrtek02',	'2022-01-06 10:36:32',	'2022-01-06 10:36:32',	0);

-- 2022-06-06 08:51:43
